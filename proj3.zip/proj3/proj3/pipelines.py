# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
import sqlite3

class Proj3Pipeline:
    def __init__(self):
        self.conectsqlite()
        self.createtable()
        
    def conectsqlite(self):
        self.conn = sqlite3.connect('asdf.db')
        self.cur=self.conn.cursor()
        
    def createtable(self):
        self.cur.execute("""DROP TABLE IF EXISTS abdu""")
        self.cur.execute("""create table abdu(name text)""")
        
    
    def process_item(self, item, spider):
        self.insert1(item)
        return item
    def insert1(self,item):
        self.cur.execute("""insert into abdu values(?)""",(item['name']))
        self.conn.commit()
