# -*- coding: utf-8 -*-
"""
Created on Tue Jan 17 22:29:59 2023

@author: abdul
"""

import scrapy
from ..items import *

class QuoteScrapy(scrapy.Spider):
    name='proj3'
    start_urls=['https://quotes.toscrape.com/']
    def parse(self, response):
        item=Proj3Item()
        quotes=response.css('div.quote')
        for i in quotes:
            a=i.css('span.text::text').extract()
            item['name']=a
            yield item
